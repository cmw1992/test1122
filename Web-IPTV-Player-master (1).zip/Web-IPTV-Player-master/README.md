# Web IPTV Player
You can add or remove links by editing index.php

# http://iptvde.mypressonline.com
